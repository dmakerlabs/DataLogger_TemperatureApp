Arduino IoT Cloud historic data

variables:
  - id: 882b483c-9cb3-4910-96f7-1ec6a688481e
    name: Temperatura
    thingName: Temperatura e Humidade
  - id: 05b37585-b2b3-4759-a176-77e7db3df8d6
    name: Humidade
    thingName: Temperatura e Humidade
  - id: b7f34586-a230-4726-8b4e-e76871f373c5
    name: msg
    thingName: Temperatura e Humidade
from: 2023-09-25T00:00:00Z
to: 2023-09-27T23:59:59Z

Have fun! :)
